# Neoard Launcher 0.1 — fondasi UI

Project Android Kotlin + Jetpack Compose dengan nama aplikasi **Neoard Launcher**.

## Yang sudah ada
- Navigasi Play, Version Download, Resource Pack, Shaders, Installed, Settings, Skins, Profile.
- Tampilan adaptif: sidebar pada layar lebar dan navigation bar pada ponsel.
- Halaman Version Download dengan kategori Release, Snapshot, Alpha, Beta, Terlama.
- Pilihan loader Vanilla, Forge, Fabric, OptiFine, Quilt, NeoForge.
- Halaman Play dan konsep Quick World Launch.

## Batasan penting versi ini
Ini adalah **prototype UI**, belum launcher Minecraft Java yang benar-benar menjalankan game.
Daftar versi masih contoh, tombol Install dan Play hanya memberi pemberitahuan. Belum ada pengunduh manifest/client, installer Forge/Fabric/OptiFine/Quilt/NeoForge, runtime Java, renderer Android, login, atau pembaca world. Integrasi tersebut perlu dibuat dan diuji bertahap; jangan menganggap APK ini sudah bisa memainkan Minecraft.

## Build
1. Buka project ini di Android Studio.
2. Gunakan JDK 17.
3. Tunggu Gradle Sync.
4. Pilih Build > Build APK(s).
5. APK debug biasanya muncul di `app/build/outputs/apk/debug/app-debug.apk`.

Package: `com.neoard.launcher`
Minimum Android: 8.0 (API 26)
Target SDK: 35
