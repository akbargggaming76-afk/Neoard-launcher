package com.neoard.launcher

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Purple = Color(0xFF7048B8)
private val Pale = Color(0xFFF3EFFB)
private val Ink = Color(0xFF21183A)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NeoardApp() }
    }
}

private data class NavItem(val title: String, val icon: ImageVector)
private data class GameVersion(val id: String, val kind: String, val note: String)

@Composable
private fun NeoardApp() {
    val navItems = listOf(
        NavItem("Play", Icons.Default.PlayArrow),
        NavItem("Version Download", Icons.Default.Download),
        NavItem("Resource Pack", Icons.Default.Layers),
        NavItem("Shaders", Icons.Default.WbSunny),
        NavItem("Installed", Icons.Default.Folder),
        NavItem("Settings", Icons.Default.Settings),
        NavItem("Skins", Icons.Default.Person),
        NavItem("Profile", Icons.Default.AccountCircle)
    )
    var selected by remember { mutableStateOf("Play") }
    var selectedVersion by remember { mutableStateOf("1.21.10") }
    var selectedLoader by remember { mutableStateOf("Vanilla") }
    var selectedCategory by remember { mutableStateOf("Release") }
    var lastWorld by remember { mutableStateOf("Belum dipilih") }
    val context = LocalContext.current

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Purple,
            onPrimary = Color.White,
            background = Pale,
            surface = Color.White,
            onSurface = Ink
        )
    ) {
        BoxWithConstraints(Modifier.fillMaxSize().background(Pale)) {
            val wide = maxWidth >= 700.dp
            if (wide) {
                Row(Modifier.fillMaxSize().padding(12.dp)) {
                    Column(
                        Modifier.width(218.dp).fillMaxHeight()
                            .padding(end = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(7.dp)
                    ) {
                        Brand()
                        Spacer(Modifier.height(12.dp))
                        navItems.forEach { item ->
                            NavigationButton(item, selected == item.title) { selected = item.title }
                        }
                        Spacer(Modifier.weight(1f))
                        Text("Neoard Launcher • 0.1", color = Purple, fontSize = 12.sp)
                    }
                    Column(Modifier.weight(1f).fillMaxHeight()) {
                        Header()
                        ScreenContent(
                            selected, selectedVersion, selectedLoader, selectedCategory,
                            onVersion = { selectedVersion = it },
                            onLoader = { selectedLoader = it },
                            onCategory = { selectedCategory = it },
                            onInstall = {
                                Toast.makeText(context,
                                    "UI demo: pemasangan loader belum diaktifkan.",
                                    Toast.LENGTH_LONG).show()
                            },
                            onPlay = {
                                Toast.makeText(context,
                                    "Mesin Minecraft belum terhubung. Ini masih fondasi UI 0.1.",
                                    Toast.LENGTH_LONG).show()
                            },
                            lastWorld = lastWorld,
                            onWorld = { lastWorld = it }
                        )
                    }
                }
            } else {
                Column(Modifier.fillMaxSize()) {
                    Header()
                    ScreenContent(
                        selected, selectedVersion, selectedLoader, selectedCategory,
                        onVersion = { selectedVersion = it },
                        onLoader = { selectedLoader = it },
                        onCategory = { selectedCategory = it },
                        onInstall = {
                            Toast.makeText(context, "UI demo: pemasangan loader belum diaktifkan.", Toast.LENGTH_LONG).show()
                        },
                        onPlay = {
                            Toast.makeText(context, "Mesin Minecraft belum terhubung. Ini masih fondasi UI 0.1.", Toast.LENGTH_LONG).show()
                        },
                        lastWorld = lastWorld,
                        onWorld = { lastWorld = it },
                        modifier = Modifier.weight(1f)
                    )
                    NavigationBar(containerColor = Color.White) {
                        navItems.take(5).forEach { item ->
                            NavigationBarItem(
                                selected = selected == item.title,
                                onClick = { selected = item.title },
                                icon = { Icon(item.icon, null) },
                                label = { Text(item.title, fontSize = 9.sp) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Brand() {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("N", color = Purple, fontSize = 42.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.width(8.dp))
        Column {
            Text("Neoard Launcher", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Ink)
            Text("Minecraft Java Edition", fontSize = 12.sp, color = Purple)
        }
    }
}

@Composable
private fun Header() {
    Row(
        Modifier.fillMaxWidth().padding(start = 8.dp, end = 8.dp, bottom = 10.dp),
        horizontalArrangement = Arrangement.End,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Surface(shape = RoundedCornerShape(50), color = Color.White) {
            Row(Modifier.padding(horizontal = 14.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.AccountCircle, null, tint = Purple)
                Spacer(Modifier.width(7.dp))
                Text("Offline Player", color = Ink, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
private fun NavigationButton(item: NavItem, active: Boolean, onClick: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth().height(47.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(24.dp),
        color = if (active) Color(0xFFE4D8FA) else Color.Transparent
    ) {
        Row(Modifier.padding(horizontal = 13.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(item.icon, null, tint = if (active) Purple else Color(0xFF66558A))
            Spacer(Modifier.width(12.dp))
            Text(item.title, color = Ink, fontWeight = if (active) FontWeight.Bold else FontWeight.Medium, fontSize = 14.sp)
        }
    }
}

@Composable
private fun ScreenContent(
    screen: String,
    version: String,
    loader: String,
    category: String,
    onVersion: (String) -> Unit,
    onLoader: (String) -> Unit,
    onCategory: (String) -> Unit,
    onInstall: () -> Unit,
    onPlay: () -> Unit,
    lastWorld: String,
    onWorld: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier.fillMaxSize().padding(4.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        when (screen) {
            "Version Download" -> VersionScreen(version, loader, category, onVersion, onLoader, onCategory, onInstall)
            "Play" -> PlayScreen(version, loader, lastWorld, onPlay, onWorld)
            else -> PlaceholderScreen(screen)
        }
    }
}

@Composable
private fun Panel(content: @Composable ColumnScope.() -> Unit) {
    Surface(
        color = Color.White,
        shape = RoundedCornerShape(24.dp),
        tonalElevation = 1.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp), content = content)
    }
}

@Composable
private fun VersionScreen(
    version: String, loader: String, category: String,
    onVersion: (String) -> Unit, onLoader: (String) -> Unit,
    onCategory: (String) -> Unit, onInstall: () -> Unit
) {
    val categories = listOf("Semua", "Release", "Snapshot", "Alpha", "Beta", "Terlama")
    val loaders = listOf("Vanilla", "Forge", "Fabric", "OptiFine", "Quilt", "NeoForge")
    val versions = when (category) {
        "Snapshot" -> listOf(GameVersion("25w14a", "Snapshot", "Snapshot pengembangan"))
        "Alpha" -> listOf(GameVersion("a1.0.16_02", "Alpha", "Alpha klasik"))
        "Beta" -> listOf(GameVersion("b1.7.3", "Beta", "Beta klasik"))
        "Terlama" -> listOf(GameVersion("1.0.0", "Release lama", "Rilis awal Java Edition"))
        else -> listOf(
            GameVersion("1.21.10", "Release", "Versi stabil terbaru (contoh UI)"),
            GameVersion("1.21.9", "Release", "Versi stabil"),
            GameVersion("1.21.8", "Release", "Versi stabil"),
            GameVersion("1.20.6", "Release", "Versi stabil"),
            GameVersion("1.20.1", "Release", "Versi populer")
        )
    }
    Panel {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Download, null, tint = Purple, modifier = Modifier.size(30.dp))
            Spacer(Modifier.width(10.dp))
            Column {
                Text("Version Download", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Ink)
                Text("Cari versi Minecraft dan pilih loader favoritmu.", color = Purple)
            }
        }
        var query by remember { mutableStateOf("") }
        OutlinedTextField(
            value = query, onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            placeholder = { Text("Cari versi… (contoh: 1.21.10)") },
            leadingIcon = { Icon(Icons.Default.Search, null) },
            shape = RoundedCornerShape(24.dp)
        )
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            categories.forEach { c ->
                FilterChip(selected = category == c, onClick = { onCategory(c) }, label = { Text(c) })
            }
        }
        Text("Pilih loader", fontWeight = FontWeight.Bold, color = Ink)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            loaders.forEach { l ->
                FilterChip(selected = loader == l, onClick = { onLoader(l) }, label = { Text(l, fontSize = 11.sp) })
            }
        }
        versions.filter { it.id.contains(query, ignoreCase = true) }.forEach { v ->
            Surface(color = Pale, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                Row(
                    Modifier.fillMaxWidth().padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Inventory2, null, tint = Purple)
                    Spacer(Modifier.width(9.dp))
                    Column(Modifier.weight(1f)) {
                        Text(v.id, fontWeight = FontWeight.Bold, color = Ink)
                        Text("${v.kind} • ${v.note}", fontSize = 11.sp, color = Purple)
                    }
                    Button(onClick = { onVersion(v.id); onInstall() }, shape = RoundedCornerShape(18.dp)) {
                        Text("Install")
                    }
                }
            }
        }
        Text(
            "Catatan: daftar ini masih data contoh. Koneksi ke manifest resmi dan installer loader akan dibuat pada tahap berikutnya.",
            color = Color(0xFF766A8D), fontSize = 11.sp
        )
    }
}

@Composable
private fun PlayScreen(version: String, loader: String, lastWorld: String, onPlay: () -> Unit, onWorld: (String) -> Unit) {
    Panel {
        Text("Ready to play", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Ink)
        Text("Minecraft $version • $loader • Profile Offline Player", color = Purple)
        Button(onClick = onPlay, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp)) {
            Icon(Icons.Default.PlayArrow, null)
            Spacer(Modifier.width(6.dp))
            Text("Play Minecraft $version")
        }
        Text("Quick World Launch", fontWeight = FontWeight.Bold, color = Ink)
        Text("World terakhir: $lastWorld", color = Purple)
        OutlinedButton(onClick = { onWorld("World contoh") }, modifier = Modifier.fillMaxWidth()) {
            Text("Pilih / ingat world (UI demo)")
        }
        Text("Quick Play akan langsung membuka world terakhir setelah mesin Minecraft dan daftar world terintegrasi.", fontSize = 12.sp, color = Color.Gray)
    }
}

@Composable
private fun PlaceholderScreen(name: String) {
    Panel {
        Text(name, fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Ink)
        Text("Halaman $name sudah disiapkan. Fungsinya akan diisi bertahap.", color = Purple)
    }
}
